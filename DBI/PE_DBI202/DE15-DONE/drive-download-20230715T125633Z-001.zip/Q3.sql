SELECT tp.proid, tp.proname, ts.supname
FROM tblProducts tp
JOIN tblSuppliers ts ON tp.supcode = ts.supcode
WHERE ts.supcode = 'HV';
