-- Create the procedure
CREATE PROCEDURE procProductNumber
    @supcode nchar(2),
    @Productnumber int OUTPUT
AS
BEGIN
    SELECT @Productnumber = COUNT(*)
    FROM tblProducts
    WHERE supcode = @supcode;
END;
GO

-- Declare variables and execute the procedure
DECLARE @Productnumber int;
EXEC procProductNumber 'MT', @Productnumber OUTPUT;

-- Retrieve the result
SELECT @Productnumber;
