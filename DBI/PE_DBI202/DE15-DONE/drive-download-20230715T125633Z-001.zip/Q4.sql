SELECT tp.proname, SUM(tid.quantity) AS [Total quantity]
FROM tblProducts tp
JOIN tblInv_Detail tid ON tp.proid = tid.proid
WHERE tp.proid = 'RTPL02'
GROUP BY tp.proname;
