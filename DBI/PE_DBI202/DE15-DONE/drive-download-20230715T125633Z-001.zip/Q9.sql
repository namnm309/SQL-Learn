-- Modify the existing trigger
ALTER TRIGGER tr_PrintTotalAmount
ON tblInv_Detail
AFTER INSERT
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @invid nchar(6);
    DECLARE @totalAmount int;

    -- Get the invid of the inserted line
    SELECT @invid = invid
    FROM inserted;

    -- Calculate the total amount for the specific invid
    SELECT @totalAmount = SUM(quantity * price)
    FROM tblInv_Detail
    WHERE invid = @invid
    GROUP BY invid;
END;
