DELETE FROM tblInvoices
WHERE customer = 'Le Minh Phuong';
