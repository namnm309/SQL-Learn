SELECT TOP 1 invid, SUM(quantity * price) AS [Total Amount]
FROM tblInv_Detail
GROUP BY invid
ORDER BY [Total Amount] DESC;
