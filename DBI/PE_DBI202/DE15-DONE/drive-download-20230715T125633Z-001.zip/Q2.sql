SELECT invid, invdate, customer, employeeid
FROM tblInvoices
WHERE employeeid = 'S002';
