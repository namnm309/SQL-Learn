SELECT i.invid, i.invdate, d.proid, d.quantity, d.price
FROM tblInvoices i
JOIN tblInv_Detail d ON i.invid = d.invid
WHERE i.employeeid = 'S003';
