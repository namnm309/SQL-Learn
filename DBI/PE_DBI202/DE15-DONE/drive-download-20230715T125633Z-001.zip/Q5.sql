SELECT employeeid, COUNT(*) AS [Total Number]
FROM tblInvoices
GROUP BY employeeid;
